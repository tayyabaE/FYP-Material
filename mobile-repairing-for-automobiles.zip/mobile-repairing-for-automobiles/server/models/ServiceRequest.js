const mongoose = require("mongoose");

const ServiceRequestSchema = new mongoose.Schema({

  // who created request
  customer: { type: mongoose.Schema.Types.ObjectId, ref: "user", required: true },
  vehicle: { type: mongoose.Schema.Types.ObjectId, ref: "vehicle", required: true },
  service: { type: mongoose.Schema.Types.ObjectId, ref: "service", required: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: "category", required: true },
  minPrice: Number,
  maxPrice: Number,
  customerOfferedPrice: Number,      // customer cannot go below minPrice
  mechanicOfferedPrice: Number,      // mechanic cannot exceed maxPrice
  mechanic: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
  workshop: { type: mongoose.Schema.Types.ObjectId, ref: "workshop" },
  status: {
    type: String,
    enum: [
      "pending",         // just created by customer
      "sent-to-mechanics",
      "counter-offer",   // mechanic sends price
      "approved",        // mechanic approves
      "declined",        // mechanic declined
      "completed"        // service done
    ],
    default: "pending"
  },

}, { timestamps: true });

const ServiceRequest = mongoose.model("serviceRequest", ServiceRequestSchema)
module.exports = ServiceRequest
