const mongoose = require('mongoose')
const { Schema } = mongoose

const UserSchema = new Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true },
    username: { type: String, required: true },
    password: { type: String, required: true },
    phone: { type: String, required: true },
    role: { type: Number, required: true },
    status: { type: Number, default: 1 }
}, { timestamps: true })

const User = mongoose.model('user', UserSchema)
module.exports = User

// Roles
// 1 - Admin
// 2 - Vendor
// 3 - Mechanic
// 4 - Customer

// Status
// -1 - Ban
// 0 - Inactive
// 1 - Active
// 2 - Deleted