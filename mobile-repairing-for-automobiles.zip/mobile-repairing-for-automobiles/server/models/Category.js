const mongoose = require("mongoose");

const CategorySchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true, trim: true },
    status: { type: Number, default: 1 } //1: active 0: inactive
}, { timestamps: true });

const Category = mongoose.model('category', CategorySchema)
module.exports = Category;
