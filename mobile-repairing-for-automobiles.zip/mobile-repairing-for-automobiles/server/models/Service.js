const mongoose = require("mongoose");
const { Schema } = mongoose

const ServiceSchema = new Schema({
  name: { type: String, required: true, trim: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: "category", required: true},
  minPrice: { type: Number, required: true },
  maxPrice: { type: Number, required: true },

  status: { type: Number, default: 1 } // 1 active, 0 inactive
}, { timestamps: true });

const Service=mongoose.model("service", ServiceSchema)
module.exports = Service;
