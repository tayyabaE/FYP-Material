const mongoose = require('mongoose')
const { Schema } = mongoose

const WorkshopSchema = new Schema({
    name: { type: String, required: true },
    owner: { type: String, required: true },
    email: { type: String, required: true },
    address: { type: String, required: true },
    phone: { type: String, required: true },
    mechanics: [{ type: mongoose.Schema.Types.ObjectId, ref: 'user' }],
    status: { type: Number, default: 1 }// active=1 inactive=0 
}, { timestamps: true })

const Workshop = mongoose.model('workshop', WorkshopSchema)
module.exports = Workshop

