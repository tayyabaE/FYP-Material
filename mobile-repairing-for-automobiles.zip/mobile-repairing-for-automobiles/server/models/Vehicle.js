const mongoose = require("mongoose");
const { Schema } = mongoose

const VehicleSchema = new Schema({
    name: { type: String, required: true },
    vehicleType: { type: String, required: true },
    plateNumber: { type: String, unique: true, sparse: true },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: "user", required: true },
    status: { type: Number, default: 1 } //1: active 0: inactive
}, { timestamps: true });

const Vehicle = mongoose.model('vehicle', VehicleSchema)
module.exports = Vehicle;
