const express = require("express");
const getAuth = require("../middlewares/getAuth");
const User = require("../models/User");
const router = express.Router();
const jwtSecret = process.env.JWT_SECRET;
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Get All Users. Using "api/auth/getAll". Login required
router.get("/getAll", getAuth, async (req, res) => {
  try {
    // If not an admin/vendor
    if (req.user.role != 1 && req.user.role != 2)
      return res.status(401).json("Not authorized to access");

    // Find all users
    const users = await User.find().sort({ createdAt: -1 });

    // Returning response to the client
    return res.status(200).json(users);
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

//Login Using "api/auth/login"
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    //user exist in db or not
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json("Invalid email or password");

    //user is active or not
    if (user.status === -1) return res.status(401).json("User is banned");
    if (user.status === 0) return res.status(401).json("User is inactive");

    //password matching
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json("Invalid email or password");

    const payload = {
      user: {
        _id: user._id,
        role: user.role,
        email: user.email,
      },
    };
    const token = jwt.sign(payload, jwtSecret, { expiresIn: "7d" });

    return res.status(200).json({
      token,
      user: {
        _id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
      },
    });
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

// Get One. Using "api/auth/getOne/:id". Login required
router.get("/getOne/:id", getAuth, async (req, res) => {
  try {
    //admin, vendoe or user itself can access
    if (
      req.user.role != 1 &&
      req.user.role != 2 &&
      req.user._id !== req.params.id
    ) {
      return res.status(401).json("Not authorized to access");
    }

    const user = await User.findById(req.params.id);
    if (!user) return res.status(401).json("User not found");

    return res.status(200).json(user);
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

// Add new user. Using "api/auth/register".
router.post("/register", async (req, res) => {
  try {
    const { firstName, lastName, email, username, password, phone, role } =
      req.body;

    //email and username should be unique
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser)
      return res.status(400).json("Email or Username already exists");

    //hsh password
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      firstName,
      lastName,
      email,
      username,
      password: hashedPassword,
      phone,
      role,
    });

    await newUser.save();
    return res.status(200).json(newUser);
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

// Update profile. Using "api/auth/updateProfile". Login required
router.put("/updateProfile/:id", getAuth, async (req, res) => {
  try {
    const { firstName, lastName, email, username, phone, password } = req.body;

    ///admin, vendoe or user itself can update
    if (
      req.user.role != 1 &&
      req.user.role != 2 &&
      req.user._id !== req.params.id
    ) {
      return res.status(401).json("Not authorized to update");
    }

    const updateData = { firstName, lastName, email, username, phone };
    if (password) {
      updateData.password = await bcrypt.hash(password, 10);
    }

    const updatedUser = await User.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    );
    if (!updatedUser) return res.status(401).json("User not found");

    return res.status(200).json(updatedUser);
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

// Ban user. Using "api/auth/ban/:id". Login required
router.put("/ban/:id", getAuth, async (req, res) => {
  try {
    //admin can ban only
    if (req.user.role != 1)
      return res.status(401).json("Not authorized to ban user");

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { status: -1 },
      { new: true }
    );
    if (!user) return res.status(401).json("User not found");

    return res.status(200).json(user);
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

// Active user. Using "api/auth/active/:id". Login required
router.put("/active/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role != 1)
      return res.status(401).json("Not authorized to activate user");

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { status: 1 },
      { new: true }
    );
    if (!user) return res.status(404).json("User not found");

    return res.status(200).json(user);
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

// Inactive user. Using "api/auth/inactive/:id". Login required
router.put("/inactive/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role != 1)
      return res.status(401).json("Not authorized to inactivate user");

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { status: 0 },
      { new: true }
    );
    if (!user) return res.status(404).json("User not found");

    return res.status(200).json(user);
  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

module.exports = router;
