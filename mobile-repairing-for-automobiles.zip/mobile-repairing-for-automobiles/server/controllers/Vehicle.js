const express = require("express");
const getAuth = require("../middlewares/getAuth");
const Vehicle = require("../models/Vehicle");
const User= require("../models/User")
const router = express.Router();

//Add a new vehicle using /api/vehicles/addVehicle
router.post("/addVehicle", getAuth, async (req, res) => {
  try {
    // Only admin/vendor
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(401).json("Not authorized to access");

    const { owner, plateNumber } = req.body;

    //owner/customer must be existing
    const user = await User.findById(owner);
    if (!user) return res.status(400).json("Owner not found");

    //role should be 4
    if (user.role !== 4)
      return res.status(400).json("Vehicle owner must be a customer");

    // Plate number already exists?
    if (plateNumber) {
      const plateExists = await Vehicle.findOne({ plateNumber });
      if (plateExists)
        return res.status(400).json("Plate number already registered");
    }

    const vehicle = await Vehicle.create(req.body);
    return res.status(201).json(vehicle);

  } catch (err) {
    console.log("Vehicle Error:", err);
    return res.status(500).json("Internal Server Error");
  }
});

//get all vehicles using /api/vehicles/getAllVehicles
router.get("/getAllVehicles", getAuth, async (req, res) => {
  try {
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(401).json("Not authorized to access");

    const vehicles = await Vehicle.find()
      .populate("owner", "firstName lastName email phone");

    return res.status(200).json(vehicles);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

//update a vehicle using /api/vehicles/updateVehicle
router.put("/updateVehicle/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(401).json("Not authorized to access");

    // If owner is being changed, validate it
    if (req.body.owner) {
      const user = await User.findById(req.body.owner);
      if (!user) return res.status(400).json("Owner not found");
      if (user.role !== 4)
        return res.status(400).json("Vehicle owner must be a customer");
    }

    const vehicle = await Vehicle.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });

    if (!vehicle) return res.status(404).json("Vehicle not found");

    return res.status(200).json(vehicle);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

//delete a vehicle using api/vehicle/deleteVehicle
router.delete("/deleteVehicle/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(401).json("Not authorized to access");

    const vehicle = await Vehicle.findByIdAndDelete(req.params.id);
    if (!vehicle) return res.status(404).json("Vehicle not found");

    return res.status(200).json("Vehicle deleted");

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});


module.exports= router;