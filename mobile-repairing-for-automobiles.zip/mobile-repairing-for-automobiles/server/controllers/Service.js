const express = require("express");
const getAuth = require("../middlewares/getAuth");
const Service = require("../models/Service");
const Category = require("../models/Category");

const router = express.Router();

//add new service /api/services/addService
router.post("/addService", getAuth, async (req, res) => {
  try {
    // admin or vendor only
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(403).json("Not authorized to add new service");

    const { name, category, minPrice, maxPrice } = req.body;

    if (!name || !category || !minPrice || !maxPrice)
      return res.status(400).json("All fields are required");

    //category exists
    const categoryExists = await Category.findById(category);
    if (!categoryExists)
      return res.status(400).json("Category not found");

    //check duplicate service name in same category
    const duplicate = await Service.findOne({
      name: name.trim(),
      category
    });

    if (duplicate)
      return res.status(400).json("Service already exists in this category");

    const service = await Service.create({
      name: name.trim(),
      category,
      minPrice,
      maxPrice
    });

    res.status(201).json(service);

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});

//get all services — /api/services/getAllServices
router.get("/getAllServices", getAuth, async (req, res) => {
  try {
    const services = await Service.find()
      .populate("category", "name status")
      .sort({ createdAt: -1 });

    res.status(200).json(services);

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});

//Update service — /api/services/updateService/:id
router.put("/updateService/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(403).json("Not authorized to update service");

    const { name, category, minPrice, maxPrice } = req.body;

    // If category changed, ensure it exists
    if (category) {
      const categoryExists = await Category.findById(category);
      if (!categoryExists)
        return res.status(400).json("Category not found");
    }

    const updated = await Service.findByIdAndUpdate(
      req.params.id,
      {
        name: name?.trim(),
        category,
        minPrice,
        maxPrice
      },
      { new: true }
    ).populate("category", "name");

    if (!updated) return res.status(404).json("Service not found");

    res.status(200).json(updated);

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});

// ➤ Delete service — /api/services/deleteService/:id
router.delete("/deleteService/:id", getAuth, async (req, res) => {
  try {
    // Only admin should delete
    if (req.user.role !== 1)
      return res.status(401).json("Not authorized to delete service");

    await Service.findByIdAndDelete(req.params.id);

    res.status(200).json("Service deleted");

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});

// ➤ Activate service — /api/services/activeService/:id
router.put("/activeService/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(401).json("Not authorized to activate service");

    const service = await Service.findByIdAndUpdate(
      req.params.id,
      { status: 1 },
      { new: true }
    );

    if (!service) return res.status(404).json("Service not found");

    return res.status(200).json(service);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

// ➤ Deactivate service — /api/services/inactiveService/:id
router.put("/inactiveService/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role !== 1 && req.user.role !== 2)
      return res.status(401).json("Not authorized to deactivate service");

    const service = await Service.findByIdAndUpdate(
      req.params.id,
      { status: 0 },
      { new: true }
    );

    if (!service) return res.status(404).json("Service not found");

    return res.status(200).json(service);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

module.exports = router;
