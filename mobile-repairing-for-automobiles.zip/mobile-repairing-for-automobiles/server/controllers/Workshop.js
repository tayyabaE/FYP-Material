const express = require('express')
const getAuth = require('../middlewares/getAuth')
const Workshop = require('../models/Workshop')
const User= require('../models/User')
const router = express.Router()

//Add new worksop. Using /api/workshops/addWorkshop
router.post("/addWorkshop", getAuth, async (req, res) => {
    try {
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized");

        const { mechanics, email, phone } = req.body;

        // Check duplicates
        const exists = await Workshop.findOne({ $or: [{ email }, { phone }] });
        if (exists)
            return res.status(400).json("Workshop with this email/phone already exists");

        // Validate mechanics if provided
        if (mechanics?.length > 0) {
            const validMechs = await User.find({ 
                _id: { $in: mechanics },
                role: 3 
            });

            if (validMechs.length !== mechanics.length)
                return res.status(400).json("Some mechanics are invalid");
        }

        const workshop = await Workshop.create(req.body);
        return res.status(201).json(workshop);

    } catch (err) {
        console.log(err);
        return res.status(500).json("Internal Server Error");
    }
});

//get all workshops. Using /api/workshops/getAll
router.get("/getAllWorkshops", getAuth, async (req, res) => {
    try {
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized");

        const workshops = await Workshop.find()
          .populate("mechanics", "firstName lastName email username phone")
          .sort({ createdAt: -1 });

        return res.json(workshops);

    } catch (err) {
        return res.status(500).json("Internal Server Error");
    }
});

//update workshop. Using /api/workshops/updateWorkshop/:id
router.put("/updateWorkshop/:id", getAuth, async (req, res) => {
    try {
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized");

        // Whitelist fields allowed to update
        const allowed = ["name","owner","email","address","phone"];
        const updates = {};

        Object.keys(req.body).forEach(key => {
            if (allowed.includes(key)) updates[key] = req.body[key];
        });

        const workshop = await Workshop.findByIdAndUpdate(req.params.id, updates, {
            new: true
        });

        if (!workshop) return res.status(404).json("Workshop not found");

        return res.json(workshop);

    } catch (err) {
        return res.status(500).json("Internal Server Error");
    }
});

//delete workshop. Using /api/workshops/deleteWorkshop/:id
router.delete("/deleteWorkshop/:id", getAuth, async (req, res) => {
    try {
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized");

        const workshop = await Workshop.findByIdAndDelete(req.params.id);
        if (!workshop) return res.status(404).json("Workshop not found");

        return res.json("Workshop deleted");

    } catch (err) {
        return res.status(500).json("Internal Server Error");
    }
});

//activate workshop using /api/workshop/active/:id
router.put("/activeWorkshop/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role != 1 && req.user.role != 2)
      return res.status(401).json("Not authorized to activate workshop");

    const workshop = await Workshop.findByIdAndUpdate(
      req.params.id,
      { status: 1 }, 
      { new: true }
    );

    if (!workshop) return res.status(404).json("Workshop not found");

    return res.status(200).json(workshop);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

//deactivate Workshop /api/workshop/inactive/:id
router.put("/inactiveWorkshop/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role != 1 && req.user.role != 2)
      return res.status(401).json("Not authorized to deactivate workshop");

    const workshop = await Workshop.findByIdAndUpdate(
      req.params.id,
      { status: 0 }, 
      { new: true }
    );

    if (!workshop) return res.status(404).json("Workshop not found");

    return res.status(200).json(workshop);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});

//Employee Management:

//Get employees of a workshop: Using /api/workshops/:id/allEmployees
router.get("/:id/allMechanics", getAuth, async (req, res) => {
    try {
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized");

        const workshop = await Workshop.findById(req.params.id)
            .populate("mechanics", "firstName lastName email username phone");

        if (!workshop) return res.status(404).json("Workshop not found");

        return res.json(workshop.mechanics);

    } catch (err) {
        return res.status(500).json("Internal Server Error");
    }
});


//Add new employee to workshop. Using /api/workshops/:id/addEmployee
router.post("/:id/addMechanic", getAuth, async (req, res) => {
    try {
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized");

        const { mechanicId } = req.body;

        const mechanic = await User.findById(mechanicId);
        if (!mechanic || mechanic.role !== 3)
            return res.status(400).json("Invalid mechanic");

        const workshop = await Workshop.findByIdAndUpdate(
            req.params.id,
            { $addToSet: { mechanics: mechanicId } },
            { new: true }
        ).populate("mechanics");

        return res.json(workshop);

    } catch (err) {
        return res.status(500).json("Internal Server Error");
    }
});

//remove employee of a workshop: Using /api/workshops/:id/removeEmployee/:mechanicId
router.delete("/:id/removeMechanic/:mechanicId", getAuth, async (req, res) => {
    try {
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized");

        const workshop = await Workshop.findByIdAndUpdate(
            req.params.id,
            { $pull: { mechanics: req.params.mechanicId } },
            { new: true }
        );

        if (!workshop) return res.status(404).json("Workshop not found");

        return res.json(workshop);

    } catch (err) {
        return res.status(500).json("Internal Server Error");
    }
});


module.exports = router
