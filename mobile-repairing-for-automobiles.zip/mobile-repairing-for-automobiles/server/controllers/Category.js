const express = require("express");
const getAuth = require("../middlewares/getAuth");
const Category = require("../models/Category")
const router = express.Router();

//add new category using /api/categories/addCategory
router.post("/addCategory", getAuth, async (req, res) => {
    try {
        //if not admin / vendor
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized to add new category");

        const { name } = req.body;

        const exist = await Category.findOne({ name: name.trim() });
        if (exist) return res.status(400).json("Category already exists");

        const category = await Category.create({ name: name.trim() });

        res.status(201).json(category);

    } catch (err) {
        console.log(err);
        res.status(500).json("Internal Server Error");
    }
});

//get all categories using /api/categories/getAllCategories
router.get("/getAllCategories", getAuth, async (req, res) => {
    try {
        const categories = await Category.find().sort({ createdAt: -1 });
        res.status(200).json(categories);

    } catch (err) {
        console.log(err);
        res.status(500).json("Internal Server Error");
    }
});

//update category using /api/categories/updateCategory/:id
router.put("/updateCategory/:id", getAuth, async (req, res) => {
    try {
        //if not admin / vendor
        if (req.user.role !== 1 && req.user.role !== 2)
            return res.status(403).json("Not authorized to update category");

        const { name } = req.body;

        const category = await Category.findByIdAndUpdate(
            req.params.id,
            { name: name?.trim() },
            { new: true }
        );

        if (!category)
            return res.status(404).json("Category not found");

        res.status(200).json(category);

    } catch (err) {
        console.log(err);
        res.status(500).json("Internal Server Error");
    }
});

//delete category using /api/categories/deleteCategory/:id
router.delete("/deleteCategory/:id", getAuth, async (req, res) => {
    try {
         //if not admin 
        if (req.user.role !== 1)
            return res.status(401).json("Not authorized to delete category");

        await Category.findByIdAndDelete(req.params.id);

        res.status(200).json("Category deleted");

    } catch (err) {
        console.log(err);
        res.status(500).json("Internal Server Error");
    }
});

// Activate Category — "api/category/active/:id"
router.put("/activeCategory/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role != 1 && req.user.role != 2)
      return res.status(401).json("Not authorized to activate category");

    const category = await Category.findByIdAndUpdate(
      req.params.id,
      { status: 1 }, 
      { new: true }
    );

    if (!category) return res.status(404).json("Category not found");

    return res.status(200).json(category);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});


// Deactivate Category — "api/category/inactive/:id"
router.put("/inactiveCategory/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role != 1 && req.user.role != 2)
      return res.status(401).json("Not authorized to inactivate category");

    const category = await Category.findByIdAndUpdate(
      req.params.id,
      { status: 0 }, 
      { new: true }
    );

    if (!category) return res.status(404).json("Category not found");

    return res.status(200).json(category);

  } catch (err) {
    console.log(err);
    return res.status(500).json("Internal Server Error");
  }
});


module.exports = router;
