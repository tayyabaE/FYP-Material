const express = require("express");
const getAuth = require("../middlewares/getAuth");
const Service = require("../models/Service");
const Category = require("../models/Category");
const ServiceRequest = require("../models/ServiceRequest")

const router = express.Router();

router.post("/create", getAuth, async (req, res) => {
  try {
    const { serviceId, vehicleId, offeredPrice } = req.body;

    const service = await Service.findById(serviceId);
    if (!service) return res.status(404).json("Service not found");

    // Validate price
    if (offeredPrice < service.minPrice)
      return res.status(400).json(`Minimum allowed price is ${service.minPrice}`);

    if (offeredPrice > service.maxPrice)
      return res.status(400).json(`Maximum allowed price is ${service.maxPrice}`);

    const newRequest = await ServiceRequest.create({
      customer: req.user._id,
      vehicle: vehicleId,
      service: serviceId,
      category: service.category,
      minPrice: service.minPrice,
      maxPrice: service.maxPrice,
      customerOfferedPrice: offeredPrice,
      status: "pending"
    });

    res.status(201).json(newRequest);

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});

router.put("/approve/:id", getAuth, async (req, res) => {
  try {
    if (req.user.role !== 3)
      return res.status(403).json("Only mechanics can approve requests");

    const request = await ServiceRequest.findById(req.params.id);
    if (!request) return res.status(404).json("Request not found");

    request.mechanic = req.user._id;
    request.workshop = req.user.workshop;
    request.status = "approved";
    request.mechanicOfferedPrice = request.customerOfferedPrice;

    await request.save();
    res.status(200).json(request);

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});

router.put("/decline/:id", getAuth, async (req, res) => {
  try {
    const request = await ServiceRequest.findByIdAndUpdate(
      req.params.id,
      { status: "declined" },
      { new: true }
    );

    if (!request) return res.status(404).json("Request not found");

    res.status(200).json(request);

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});

router.put("/counter/:id", getAuth, async (req, res) => {
  try {
    const { price } = req.body;

    const request = await ServiceRequest.findById(req.params.id);
    if (!request) return res.status(404).json("Request not found");

    if (price > request.maxPrice)
      return res.status(400).json(`Counter price cannot exceed ${request.maxPrice}`);

    request.mechanic = req.user._id;
    request.workshop = req.user.workshop;
    request.mechanicOfferedPrice = price;
    request.status = "counter-offer";

    await request.save();
    res.status(200).json(request);

  } catch (err) {
    console.log(err);
    res.status(500).json("Internal Server Error");
  }
});


module.exports=router;