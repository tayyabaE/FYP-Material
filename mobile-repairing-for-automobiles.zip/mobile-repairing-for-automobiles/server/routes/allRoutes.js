const express = require('express')
const router = express.Router()

// Controllers Here
const User = require('../controllers/User')
const Workshop = require('../controllers/Workshop')
const Vehicle = require('../controllers/Vehicle')
const Category = require('../controllers/Category')
const Service = require('../controllers/Service')

// Base Routes Here
router.use("/auth", User)
router.use("/workshops", Workshop)
router.use("/vehicles", Vehicle)
router.use("/categories", Category)
router.use("/services", Service)


module.exports = router